#include "ti_msp_dl_config.h"
#include "motor.h"

volatile int32_t target_dis = 0;
volatile int32_t target_yaw = 0;
volatile uint8_t car_state = STOP;

//���س���״̬��ѭ����Ѳ�ߣ�ֹͣ������ת����ת
uint8_t get_car_state(void)
{
    return car_state;
}

//speed -1000--1000
void set_speed_left(int16_t speed)
{
    if(speed > 1000)
        speed = 1000;
    else if(speed < -1000)
        speed = -1000;
    else if(speed == 0)
    {
        DL_GPIO_setPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_AIN2_PIN);
        DL_GPIO_setPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_AIN1_PIN);
        DL_Timer_setCaptureCompareValue(PWM_0_INST, 0, DL_TIMER_CC_0_INDEX);
    }
    else if (speed >= 0)
    {
        DL_GPIO_setPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_AIN2_PIN);
        DL_GPIO_clearPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_AIN1_PIN);
        DL_Timer_setCaptureCompareValue(PWM_0_INST, speed, DL_TIMER_CC_0_INDEX);
    }
    else if (speed < 0)
    {
        DL_GPIO_setPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_AIN1_PIN);
        DL_GPIO_clearPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_AIN2_PIN);
        DL_Timer_setCaptureCompareValue(PWM_0_INST, -speed, DL_TIMER_CC_0_INDEX);
    }
}

//speed -1000--1000
void set_speed_right(int16_t speed)
{
    if(speed > 1000)
        speed = 1000;
    else if(speed < -1000)
        speed = -1000;
    else if(speed == 0)
    {
        DL_GPIO_setPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_BIN2_PIN);
        DL_GPIO_setPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_BIN1_PIN);
        DL_Timer_setCaptureCompareValue(PWM_0_INST, 0, DL_TIMER_CC_1_INDEX);
    }
    else if (speed > 0)
    {
        DL_GPIO_setPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_BIN2_PIN);
        DL_GPIO_clearPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_BIN1_PIN);
        DL_Timer_setCaptureCompareValue(PWM_0_INST, speed, DL_TIMER_CC_1_INDEX);
    }
    else if (speed < 0)
    {
        DL_GPIO_setPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_BIN1_PIN);
        DL_GPIO_clearPins(TB6612_CONTROL_GRP_PORT, TB6612_CONTROL_GRP_BIN2_PIN);
        DL_Timer_setCaptureCompareValue(PWM_0_INST, -speed, DL_TIMER_CC_1_INDEX);
    }
}


//1cm��Ӧ17.825353626292277������~~17.82535
//�趨Ŀ�����
void set_target(float cm, Count *count, PID *pid_position, PID *pid_left, PID *pid_right)
{

    encoder_delete_all(count);
    PID_Clear(pid_position);
    PID_Clear(pid_left);
    PID_Clear(pid_right);
    car_state = TRACK;
    //������Ҫ��������
    target_dis = 17.82535 * (float)cm;
}

//������ٶȻ�
void motor_speed_pid(Count *count, PID *pid_left, PID *pid_right, int excpet_left, int except_right)
{
    PID_Position(pid_left, excpet_left, count->err_left);
    PID_Position(pid_right, except_right, count->err_right);
    set_speed_left(pid_left->Output);
    set_speed_right(pid_right->Output);
}

// �����λ�û�����ѭ��
uint8_t motor_controll(Count *count, PID *pid_position, PID *pid_left, PID *pid_right)
{
    PID_Position(pid_position, target_dis, ((float)count->sum_left + (float)count->sum_right) / 2.0f);

    if (-5 < pid_position->Error && pid_position->Error < 5)
    {
        return ON_POSITION;
    }

    motor_speed_pid(count, pid_left, pid_right, pid_position->Output, pid_position->Output);
    return OFF_POSITION;
}

// �����λ�û����Ҷ�ѭ������д
uint8_t motor_controll_gray(Count *count, PID *pid_position, PID *pid_left, PID *pid_right, uint8_t *gray_data)
{
    PID_Position(pid_position, target_dis, ((float)count->sum_left + (float)count->sum_right) / 2.0f);

    //set_offset(gray_data);

    if (-5 < pid_position->Error && pid_position->Error < 5)
    {
        return ON_POSITION;
    }

    //��ƫ����
    motor_speed_pid(count, pid_left, pid_right, pid_position->Output, pid_position->Output);
    return OFF_POSITION;
}

// �����λ�û�������ͷѭ��
uint8_t motor_controll_camera(Count *count, PID *pid_theta, PID *pid_rho, PID *pid_position, PID *pid_left, PID *pid_right, int16_t rho_err, int16_t theta_err)
{
    PID_Position(pid_position, target_dis, ((float)count->sum_left + (float)count->sum_right) / 2.0f);
    static float sum = 0;
    PID_Position(pid_theta, 0, theta_err);
    PID_Position(pid_rho, 0, rho_err);
    sum = pid_rho->Output + pid_theta->Output;
    motor_speed_pid(count, pid_left, pid_right, pid_position->Output - (int)sum, pid_position->Output + (int)sum);
    if (-5 < pid_position->Error && pid_position->Error < 5)
    {
        return ON_POSITION;
    }
    else
        return OFF_POSITION;
}

//�趨ת���Ƕ�,�趨ȫ�ֱ���target_yaw
void set_trun(uint8_t State, Count *count, PID *pid_position, PID *pid_left, PID *pid_right, PID *pid_yaw)
{
    encoder_delete_all(count);
    PID_Clear(pid_left);
    PID_Clear(pid_right);
    PID_Clear(pid_position);
    PID_Clear(pid_yaw);
    if (State == TURN_LEFT)
    {
        target_yaw = mpu6050.yaw + 90;
        car_state = TURN_LEFT;
    }
    else if (State == TURN_RIGHT)
    {
         target_yaw = mpu6050.yaw - 90;
        car_state = TURN_RIGHT;
    }
    else if (State == TURN_BACK)
    {
         target_yaw = mpu6050.yaw - 180;
        car_state = TURN_BACK;
    }
    else
        return;
}

//ͨ��ȫ�ֱ���target_yaw����yaw��Ŀ��ֵ�Ĳ�ֵ,����pid����
float yaw_error(void)
{
     float err = target_yaw - mpu6050.yaw;
     if(err > 180.0f) err -= 360.0f;
     else if(err < -180.0f) err += 360.0f;
     return err;
}

//��̬��+ת��ʵ��ת��
uint8_t motor_controll_turn(Count *count, PID *pid_yaw, PID *pid_left, PID *pid_right)
{
    if (car_state == TURN_LEFT)
    {
        PID_Position(pid_yaw, 0.0f, yaw_error());
        motor_speed_pid(count, pid_left, pid_right, pid_yaw->Output, -pid_yaw->Output);
    }
    else if (car_state == TURN_RIGHT)
    {
        PID_Position(pid_yaw, 0.0f, yaw_error());
        motor_speed_pid(count, pid_left, pid_right, -pid_yaw->Output, pid_yaw->Output);
    }
    else if (car_state == TURN_BACK)
    {
        PID_Position(pid_yaw, 0.0f, yaw_error());
        motor_speed_pid(count, pid_left, pid_right, pid_yaw->Output, -pid_yaw->Output);
    }
    if (-3 < pid_yaw->Error && pid_yaw->Error < 3)
    {
        return ON_POSITION;
    }
    return OFF_POSITION;
}




